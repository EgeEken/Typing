import time
import random
import pygame as pg

texts = set()
with open("texts.txt", 'r') as f:
    lines = f.readlines()
    for line in lines:
        if line != "":
            texts.add(line[:-1])

pg.init()

SCREENWIDTH = 1000
SCREENHEIGHT = 700

FONT = pg.font.SysFont("timesnewroman.ttf", 72)

TEXT = (20, 20, 20)
WRITTEN = (50, 200, 50)
CORRECTLETTER = (0, 255, 0)
WRONGLETTER = (200, 50, 50)
LETTER = (70, 70, 70)

BACKGROUND = (255, 255, 255)
EMPTY = (170, 170, 170)

class Game:
    def __init__(self, screenwidth = 1000, screenheight = 700): 
        self.screen = pg.display.set_mode((screenwidth, screenheight))
        self.screenwidth = screenwidth
        self.screenheight = screenheight
        self.starttime = 0 #time.time() when first character is typed
        self.text = "" #Text to type
        self.written = "" #typed part of self.text
        self.timer = 0 #time.time() - self.starttime
        self.wpm = 0 #WPM formula
        self.mistakecount = 0 #mistakes made
        self.accuracy = "100.00%" #Accuracy formula
        self.start = False
        self.maxwritten = 0
        self.state = "End" #"Play" or "End"

    def update_timer(self):
        if self.starttime != 0:
            self.timer = int(time.time() - self.starttime)
        if self.timer != 0:
            self.wpm = int((len(self.written) / 5) / (self.timer / 60))
        if len(self.written) != 0:
            self.accuracy = str(round(100 - (self.mistakecount / self.maxwritten) * 100, 2)) + '%'

    def random_text(self):
        self.text = random.choice(list(texts))
        self.written = ""
    
    def drawText(self, surface, text, color, rect, font, aa=False, bkg=None):
        rect = pg.Rect(rect)
        y = rect.top
        lineSpacing = -2

        # get the height of the font
        fontHeight = font.size("Tg")[1]

        while text:
            i = 1

            # determine if the row of text will be outside our area
            if y + fontHeight > rect.bottom:
                break

            # determine maximum width of line
            while font.size(text[:i])[0] < rect.width and i < len(text):
                i += 1

            # if we've wrapped the text, then adjust the wrap to the last word      
            if i < len(text): 
                i = text.rfind(" ", 0, i) + 1

            # render the line and blit it to the surface
            if bkg:
                image = font.render(text[:i], 1, color, bkg)
                image.set_colorkey(bkg)
            else:
                image = font.render(text[:i], aa, color)

            surface.blit(image, (rect.left, y))
            y += fontHeight + lineSpacing

            # remove the text we just blitted
            text = text[i:]

        return text

    def update(self):
        self.screen.fill(EMPTY)
        WPM_text = FONT.render(f"WPM: {self.wpm}", True, TEXT)
        ACCURACY_text = FONT.render(f"Accuracy: {self.accuracy}", True, TEXT)
        TIMER_text = FONT.render(f"{self.timer}", True, TEXT)
        self.screen.blit(WPM_text, (0, 0))
        self.screen.blit(TIMER_text, (self.screenwidth - TIMER_text.get_width(), 0))
        self.screen.blit(ACCURACY_text, ((self.screenwidth - ACCURACY_text.get_width())//2, 0))

        self.drawText(self.screen, self.text, LETTER, (0,WPM_text.get_height()*2, self.screenwidth, self.screenheight), FONT)
        self.drawText(self.screen, self.written, WRITTEN, (0,WPM_text.get_height()*2, self.screenwidth, self.screenheight), FONT)

        if len(self.written) > 0 and len(self.text) != len(self.written):
            lastchar = ""
            for i in self.written[:-1]:
                lastchar += i
            if self.written == self.text[:len(self.written)]:
                self.drawText(self.screen, lastchar, CORRECTLETTER, (0,WPM_text.get_height()*2, self.screenwidth, self.screenheight), FONT)
            else:
                lastchar += self.written[-1]
                self.drawText(self.screen, lastchar, WRONGLETTER, (0,WPM_text.get_height()*2, self.screenwidth, self.screenheight), FONT)

        pg.display.update()
    
    def menu(self):
        self.screen.fill(BACKGROUND)
        pressspace = FONT.render("Press space to play", True, TEXT)
        if self.wpm > 0:
            scorecount = FONT.render(f'WPM: {self.wpm}', True, TEXT)
            accuracy = FONT.render(f'Accuracy: {self.accuracy}', True, TEXT)
            self.screen.blit(scorecount, (10, 10))
            self.screen.blit(accuracy, (10, 10 + scorecount.get_height()))
        self.screen.blit(pressspace, (10, 10 + pressspace.get_height() * 2))
        pg.display.update()
        for event in pg.event.get():
            if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                pg.quit()
            elif event.type == pg.KEYDOWN and event.key == pg.K_SPACE:
                self.start = False
                self.state = "Play"

    def resetvars(self):
        self.starttime = 0
        self.accuracy = "100.00%"
        self.mistakecount = 0
        self.maxwritten = 0
        self.start = False

    def play(self):
        self.resetvars()
        self.random_text()
        while self.state == "Play":
            for event in pg.event.get():
                if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                    self.state = "End"
                elif event.type == pg.KEYDOWN:
                    if not self.starttime and not self.start:
                        self.starttime = time.time()
                        self.start = True
                    if event.key == pg.K_BACKSPACE:
                        self.written = self.written[:-1]
                    elif event.key == pg.K_SPACE:
                        if len(self.written) < 3 or self.written[:len(self.written) - 2] == self.text[:len(self.written) - 2]:
                            if event.unicode != '' and event.unicode != self.text[len(self.written)]:
                                self.mistakecount += 1
                        self.written += " "
                    elif len(self.written) < 3 or self.written[:len(self.written) - 2] == self.text[:len(self.written) - 2]:
                        if event.unicode != '' and event.unicode != self.text[len(self.written)]:
                            self.mistakecount += 1
                        self.written += event.unicode
            if len(self.written) > self.maxwritten:
                self.maxwritten = len(self.written)
            self.update_timer()
            self.update()
            if len(self.written) == len(self.text):
                self.state = "End"

    def run(self):
        while True:
            if self.state == "Play":
                self.play()
            elif self.state == "End":
                self.menu()

def main():
    game = Game(SCREENWIDTH, SCREENHEIGHT)
    game.run()

if __name__ == "__main__":
    main()
